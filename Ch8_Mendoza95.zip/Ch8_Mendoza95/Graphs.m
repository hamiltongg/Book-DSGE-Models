%% Impulse response functions
% Mendoza 91 model (nonlinear)

clear all;

dynare Mendoza95_irf.mod;

% 1st graph - tot shock

% % Graph (eps_px)
% names = {'Output','Investment','Consumption','Trade Balance','Terms of Trade'};
% field_name = fieldnames(oo_.irfs);
% time = 1:50;
% for j=1:size(names,2)
%         subplot(2,3,j)
%         plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
%         title(names{j});
%         grid;
%         xlim([1, 50]); % set the x-axis limit to start from 1
% end;
% orient landscape

% 2nd graph - tot shock

% % % Graph (eps_px)
% names = {'Capital for Exportables','Capital for Importables'};
% field_name = fieldnames(oo_.irfs);
% time = 1:50;
% for j=1:size(names,2)
%         subplot(1,2,j)
%         plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
%         title(names{j});
%         grid;
%         xlim([1, 50]); % set the x-axis limit to start from 1
% end;
% orient landscape

% 3rd graph - tot shock

% % Graph (eps_px)
% names = {'Real Exchange Rate','Relative Price of nontradables','Labor in Nontradables','Tradables Consumption','Nontradables Consumption','Real Interest Differential','Wages-Nontradables','Wages-Exportables','Wages-Importables'};
% field_name = fieldnames(oo_.irfs);
% time = 1:50;
% for j=1:size(names,2)
%         subplot(3,3,j)
%         plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
%         title(names{j});
%         grid;
%         xlim([1, 50]); % set the x-axis limit to start from 1
% end;
% orient landscape

% 1st graph - tot shock

% % Graph (eps_px)
% names = {'Output','Investment','Consumption','Trade Balance','Terms of Trade'};
% field_name = fieldnames(oo_.irfs);
% time = 1:50;
% for j=1:size(names,2)
%         subplot(2,3,j)
%         plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
%         title(names{j});
%         grid;
%         xlim([1, 50]); % set the x-axis limit to start from 1
% end;
% orient landscape



% 1st graph - prod shock

% % Graph (eps_p)
% names = {'Output','Investment','Consumption','Trade Balance','Productivity in Exportables','Productivity in Importables','Productivity in Nontradables'};
% field_name = fieldnames(oo_.irfs);
% time = 1:50;
% for j=1:size(names,2)
%         subplot(3,3,j)
%         plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
%         title(names{j});
%         grid;
%         xlim([1, 50]); % set the x-axis limit to start from 1
% end;
% orient landscape

% Graph (eps_p)
names = {'Real Exchange Rate','Relative Price of nontradables','Labor in Nontradables','Tradables Consumption','Nontradables Consumption','Real Interest Differential','Wages-Nontradables','Wages-Exportables','Wages-Importables'};
field_name = fieldnames(oo_.irfs);
time = 1:50;
for j=1:size(names,2)
        subplot(3,3,j)
        plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
        title(names{j});
        grid;
        xlim([1, 50]); % set the x-axis limit to start from 1
end;
orient landscape


