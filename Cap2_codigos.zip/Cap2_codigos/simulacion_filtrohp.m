%% Simulaci�n y aplicaci�n del filtro HP
%{
[1] Autor: Hamilton Galindo
[2] Fecha: Enero 2017
%}
%% Gr�fica de la simulaci�n de las variables end�genas
% Se llama al modelo
dynare Long_Plosser_Dynare_nolineal_log;

% ejemplo para el capital (kk) y el producto (yy): seis primeras
% simulaciones
periodos = 1:150;
subplot(1,2,1)
plot(periodos, kk_sim(:,1), periodos, kk_sim(:,2),periodos, kk_sim(:,3),periodos, kk_sim(:,4),periodos, kk_sim(:,5),periodos, kk_sim(:,6), 'LineWidth',1.5)
title('Capital (lnk - lnk_{ss})' );
subplot(1,2,2)
plot(periodos, yy_sim(:,1), periodos, yy_sim(:,2),periodos, yy_sim(:,3),periodos, yy_sim(:,4),periodos, yy_sim(:,5),periodos, yy_sim(:,6), 'LineWidth',1.5)
title('Producto (lny - lny_{ss})');
orient landscape
saveas(gcf,'simulacion_nolineal_log','pdf');
%% Aplicaci�n del filtro HP (funci�n de Matlab)
[trend_k,ciclo_k] =hpfilter(kk_sim(:,1),1600);
subplot(1,2,1)
plot(periodos, kk_sim(:,1),periodos,trend_k, 'LineWidth',1.5);
legend('Capital', 'Tendencia del capital');
title('El capital y su componente tendencial');
subplot(1,2,2)
plot(periodos,ciclo_k, 'LineWidth',1.5);
title('El componente ciclico del capital');

orient landscape
saveas(gcf,'hpfilter_nolineal_log','pdf');