%% Impulse response functions
% Mendoza 91 model (nonlinear)

clear all;

dynare Mendoza91_log;

% Graph (e_e)
names = {'Output', 'Consumption', 'Capital', 'Investment', 'Labor', 'Real wage', 'Capital rent', 'Real interest rate', 'Risk premium', 'Foreign bonds', 'Trade balance-Output', 'Current account-Output', 'Productivity shock'};
field_name = fieldnames(oo_.irfs);
time = 1:10;
for j=1:size(names,2)
        subplot(4,4,j)
        plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
        title(names{j});
        grid;
        xlim([1, 10]); % set the x-axis limit to start from 1
end;
orient landscape


% % Graph (e_n)
% names = {'Output', 'Consumption', 'Capital', 'Investment', 'Labor', 'Real wage', 'Capital rent', 'Real interest rate', 'Risk premium', 'Foreign bonds', 'Trade balance-Output', 'Current account-Output', 'External rate shock'};
% field_name = {'yy_e_n', 'cc_e_n', 'kk_e_n', 'ii_e_n', 'hh_e_n', 'ww_e_n', 'rk_e_n', 'rf_e_n', 'rp_e_n', 'a_e_n', 'tb_y_e_n', 'ca_y_e_n', 'n_e_n'};
% time = 1:10;
% for j=1:size(names,2)
%         subplot(4,4,j)
%         plot(time,oo_.irfs.(field_name{j}),'LineWidth', 1.5,'color','blue')
%         title(names{j});
%         grid;
%         xlim([1, 10]); % set the x-axis limit to start from 1
% end;
% orient landscape
% 
% print('/Users/javier/Desktop/CIUP/RBC_Book/RBC_Book_English_Version2022/chapter10-InProgress-Marco/c10figs/irfs_2.pdf', '-dpdf', '-bestfit');

% Sensivity analysis for moments

% % phi = 0.028
% gamma=2;
% omega=1.455;
% alpha=0.32;
% delta=0.1;
% phi=0.028;
% x=0.000742;
% dbar=0.7442;
% rr=0.04;
% rho=0.42; 
% 
% save param0 beta alpha delta rho gamma x omega phi dbar rr;
% dynare mendoza91_log_loop;
% 
% % phi = 0
% gamma=2;
% omega=1.455;
% alpha=0.32;
% delta=0.1;
% phi=0;
% x=0.000742;
% dbar=0.7442;
% rr=0.04;
% rho=0.42; 
% 
% save param0 beta alpha delta rho gamma x omega phi dbar rr;
% dynare mendoza91_log_loop;
% 
% %phi = 5
% gamma=2;
% omega=1.455;
% alpha=0.32;
% delta=0.1;
% phi=5;
% x=0.000742;
% dbar=0.7442;
% rr=0.04;
% rho=0.42; 
% 
% save param0 beta alpha delta rho gamma x omega phi dbar rr;
% dynare mendoza91_log_loop;
% % 
% 
% %rho = 0.05
% gamma=2;
% omega=1.455;
% alpha=0.32;
% delta=0.1;
% phi=0.028;
% x=0.000742;
% dbar=0.7442;
% rr=0.04;
% rho=0.05; 
% 
% save param0 beta alpha delta rho gamma x omega phi dbar rr;
% dynare mendoza91_log_loop;
% 
% 
% %rho = 0.42
% gamma=2;
% omega=1.455;
% alpha=0.32;
% delta=0.1;
% phi=0.028;
% x=0.000742;
% dbar=0.7442;
% rr=0.04;
% rho=0.42; 
% 
% save param0 beta alpha delta rho gamma x omega phi dbar rr;
% dynare mendoza91_log_loop;
% 
% %rho = 0.9
% gamma=2;
% omega=1.455;
% alpha=0.32;
% delta=0.1;
% phi=0.028;
% x=0.000742;
% dbar=0.7442;
% rr=0.04;
% rho=0.9; 
% 
% save param0 beta alpha delta rho gamma x omega phi dbar rr;
% dynare mendoza91_log_loop;
% 
% 
% 
