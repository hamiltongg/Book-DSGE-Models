%% Macroeconomic series (Canada)

% %% Upload data base 'Canada.xlsx'

% clear;

%% Data Base
ln_c = ln_consumption_percapita;
ln_y = ln_gdp_percapita;
ln_i = ln_investment_percapita;
ca_y = ratio_ca_gdp;
tb_y = ratio_tb_gdp;
ln_sav = ln_sav_perc; 


% drop previous variables
clear ln_sav_perc ratio_ca_gdp	ln_gdp_percapita	ln_investment_percapita	ln_consumption_percapita	ratio_tb_gdp


%% Log quadratic detrending
% Installing additional package is necessary
trend = [];
cycle = [];
Year2 = Year.^2;
x = [Year Year2];
M1 = [ln_y ln_c ln_i ln_sav];
for j=1:size(M1,2)
trend(:,j) = fitlm(x,M1(:,j)).Fitted;
cycle(:,j) = fitlm(x,M1(:,j)).Residuals.Standardized;
end;

% log-quadratic detrending of GDP
plot(Year,trend(:,1),'b--',Year,ln_y,'LineWidth',1.5);
xlim([1961 2021]);
leg1=legend('Ln(GDP) trend','Ln(GDP)');
set(leg1, 'location', 'SouthEast');
set(leg1, 'Orientation', 'Horizontal');
legend('boxoff');
orient landscape
saveas(gcf,'detr_gdp_canada','png');

% comparing time series investment and savings
plot(Year,cycle(:,3),'b--',Year,cycle(:,4),'LineWidth',1.5);
xlim([1961 2021]);
leg1=legend('Ln(savings)','Ln(investment)');
set(leg1, 'location', 'SouthEast');
set(leg1, 'Orientation', 'Horizontal');
legend('boxoff');
orient landscape
saveas(gcf,'sav_inv','pdf');
covariance_matrix = cov(cycle(:,3), cycle(:,4));
cov_s_i = covariance_matrix(1, 2);

%comparing volatilities across y c i g
subplot(2,2,1)
plot(Year,cycle(:,1),'b','LineWidth',1.5);
xlim([1961 2021]);
leg1=legend('Ln(GDP)');
set(leg1, 'location', 'NorthEast');
set(leg1, 'Orientation', 'Horizontal');
legend('boxoff');

nombres = {'ln(GDP)','ln(Consumption)','ln(Investment)'};
for j =2:3
subplot(2,1,j-1)
plot(Year,cycle(:,1),'--',Year,cycle(:,j),'LineWidth',1.5);
xlim([1961 2021]);
leg1=legend('Ln(GDP)', nombres{j});
set(leg1, 'location', 'NorthEast');
set(leg1, 'Orientation', 'Horizontal');
legend('boxoff');
end;
orient landscape
saveas(gcf,'ln_ycig','pdf');



%comparing volatilities across y tb ca
trend1 = [];
cycle1 = [];
Year2 = Year.^2;
x1 = [Year Year2];
M2 = [tb_y ca_y];
for j=1:size(M2,2)
trend1(:,j) = fitlm(x,M2(:,j)).Fitted;
cycle1(:,j) = fitlm(x,M2(:,j)).Residuals.Standardized;
end;

nombres1 = {'tb/y','ca/y'};
for j =1:2
subplot(2,1,j)
plot(Year,cycle(:,1),'--',Year,cycle1(:,j),'LineWidth',1.5);
xlim([1961 2021]);
leg1=legend('Ln(GDP)', nombres1{j});
set(leg1, 'location', 'NorthEast');
set(leg1, 'Orientation', 'Horizontal');
legend('boxoff');
end;
orient landscape
saveas(gcf,'y_tb_ca','pdf');




