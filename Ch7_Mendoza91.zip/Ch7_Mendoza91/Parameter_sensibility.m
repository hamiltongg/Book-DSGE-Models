clear all

% Corr(S,I)

phis = [0,0.028,0.1];
for j = 1:size(phis,2)
gamma=2;
omega=1.455;
alpha=0.32;
delta=0.1;
phi=phis(j);
x=0.000742;
dbar=0.7442;
rr=0.04;
rho=0.42; 

save param0 alpha delta rho gamma x omega phi dbar rr;
dynare mendoza91_log_loop ;
end;

rhos = [0.05, 0.42, 0.9];
for i = 1:size(rhos,2)
gamma=2;
omega=1.455;
alpha=0.32;
delta=0.1;
phi=0.028;
x=0.000742;
dbar=0.7442;
rr=0.04;
rho=rhos(i); 

save param0 alpha delta rho gamma x omega phi dbar rr;
dynare mendoza91_log_loop ;
end;

% Sensibility Analysis

phis = [0:0.05:0.5];
for j = 1:size(phis,2)
gamma=2;
omega=1.455;
alpha=0.32;
delta=0.1;
phi=phis(j);
x=0.000742;
dbar=0.7442;
rr=0.04;
rho=0.42; 

save param0 alpha delta rho gamma x omega phi dbar rr;
dynare mendoza91_log_loop ;
ntbp(j) = oo_.irfs.tb_y_e_e(1)
end;

rhos = [0:0.1:1]
for i = 1:size(phis,2)
gamma=2;
omega=1.455;
alpha=0.32;
delta=0.1;
phi=0.028;
x=0.000742;
dbar=0.7442;
rr=0.04;
rho=rhos(i); 

save param0 alpha delta rho gamma x omega phi dbar rr;
dynare mendoza91_log_loop ;
ntbr(i) = oo_.irfs.tb_y_e_e(1)
end;

figure('Name','Simulación de los coeficientes')
subplot(2,2,1)
plot(phis,ntbp,'LineWidth',1.5,'color','blue');
title('n_{tbe}');
xlabel('Capital adjustment costs (\phi)')
ylabel('(tb/y)_1 - (tb/y)_{ss}')
grid;
hold on 
line(get(gca,'xlim'),[0 0],'Color','r','LineWidth',1.5,'LineStyle','--') % Adds the line at y=0

subplot(2,2,2)
plot(rhos,ntbr,'LineWidth',1.5,'color','blue');
title('n_{tbe}');
xlabel('Produtivity shock persistence (\rho)')
ylabel('(tb/y)_1 - (tb/y)_{ss}')
grid;
hold on 
line(get(gca,'xlim'),[0 0],'Color','r','LineWidth',1.5,'LineStyle','--') % Adds the line at y=0
print('/Users/javier/Desktop/CIUP/RBC_Book/RBC_Book_English_Version2022/chapter10-InProgress-Marco/c10figs/sens_params.pdf', '-dpdf', '-bestfit');

