%% Modelo de Campbel (1994)
%{
Modelo A: Trabajo fijo
Autor: Hamilton Galindo
Fecha(update): Julio 2013, Setiembre 2013,Julio 2015, diciembre 2016
%}
%% Descripci�n
%{
Las secciones de este m-file son: 
[1] Calibraci�n
[2] C�lculo del estado estacionario (SS)
[3] C�lculo de los coeficientes de la soluci�n (m�todo coeficientes indeterminados)
[4] Simulaci�n: simula 100 veces las variables (para 150 periodos), basado en Cooley (1995) Cap 1 "Frontiers of Business Cycle Research"
-La simulaci�n se basa en la soluci�n del modelo
-n_simu =  n�mero de simulaciones
-periodo_final = n�mero de periodos en cada simulaci�n
[5] Aplica el filtro HP para extraer el componente c�clico de cada serie simulada
[6] Calcula los estad�sticos para cada simulaci�n
[7] Distribuciones
[8] Valores (estad�sticos) del modelo te�rico
%}

%% [1] Calibraci�n
R_ss = exp(0.015); % (Campbell supone: r = ln(R_ss) = 0.015, el cual rinde 6% anual)
alpha = 0.667;
delta = 0.025; % (10% anual)
beta = 1/R_ss;
sigma = 0.2;
phi = 0.95;
%% [2] C�lculo del estado estacionario (SS)
r_ss = R_ss - (1 - delta);
a_ss = 1;
k_ss = a_ss*(r_ss/(1-alpha))^(-1/alpha);
y_ss = a_ss^(alpha)*k_ss^(1-alpha);
i_ss = delta*k_ss;
c_ss = y_ss - i_ss;
lambda_1 = (1-delta) + delta*(1-alpha)*y_ss/i_ss; %1.0151
lambda_2 = delta*alpha*y_ss/i_ss; 
lambda_3 = alpha*r_ss/R_ss;
%% [3] C�lculo de los coeficientes de la soluci�n (m�todo coeficientes indeterminados)
Q2 = 1 -lambda_1 - lambda_2;
Q1 = lambda_1 - 1 + sigma*lambda_3*Q2;
Q0 = sigma*lambda_3*lambda_1;
n_ck = (1/(2*Q2))*(-Q1 - sqrt(Q1^2 - 4*Q0*Q2));
n_ca = (-n_ck*lambda_2 + sigma*lambda_3*(phi - lambda_2))/(phi - 1 + Q2*(n_ck + sigma*lambda_3));
n_kk = lambda_1 + (1 -lambda_1 - lambda_2)*n_ck;
n_ka = lambda_2 + (1 -lambda_1 - lambda_2)*n_ca;
%% Ecuaci�n en diferencias
% Capital
% Coef. del k(t+1) AR(2)
phi_1 = phi + n_kk;
phi_2 = -phi*n_kk;
% Raices del polinomio caracter�stico
y1 = (1/(2*phi_2))*(-phi_1 + sqrt(phi_1^2 + 4*phi_2));
y2 = (1/(2*phi_2))*(-phi_1 - sqrt(phi_1^2 + 4*phi_2));
% Coef. de la factorizaci�n en L
theta_1 = 1/y1;
theta_2 = 1/y2;
% Coef. de la versi�n MA(infinito) del AR(2)
psi_total = zeros(31,1);
periodo_final = 150; % basado en Cooley (1995) Cap 1 "Frontiers of Business Cycle Research"
for k=0:periodo_final;
    psi = [];
  for j=0:k
     psi_parcial = (theta_1^j)*(theta_2^(k-j));
     psi = [psi psi_parcial];
  end
  psi_total(k+1) = sum(psi);
end
%% [4] Simulaci�n (100) de las variables del modelo
% ======Productividad
e = randn(1);
e0 = 0;
a_sim0 = 0; %a(0) = 0
a_sim = zeros(periodo_final,1); %desde t=1: a_1, a_2...
a_sim(1)= phi*a_sim0 + e;%a(1) = n�mero aleatorio
% vamos a simular 100 veces la variable
n_simu = 100; % basado en Cooley (1995) Cap 1 "Frontiers of Business Cycle Research"
data_a_sim = []; % contiene las 100 series "a" simulada 
aleatorios = randn(periodo_final,n_simu); %desde e(1)
for jj=1:n_simu
    for j = 2:1:periodo_final
        a_sim(j) = phi*a_sim(j-1) + aleatorios(j,jj); %e(j)
    end
    data_a_sim = [data_a_sim a_sim]; 
end
% ======Capital
kk_sim0 = 0; %K(0) = 0
kk_sim1 = 0; %k(-1) = 0
kk_sim = zeros(periodo_final+1,1); %no incluye el t=0
data_kk_sim = []; % contiene el n�mero
kk_sim(1) = phi_1*kk_sim0 + phi_2*kk_sim1 + n_ka*e0;
for jj=1:n_simu
    kk_sim(2) = phi_1*kk_sim(1) + phi_2*kk_sim0 + n_ka*e;
    for j = 3:1:periodo_final+1
        kk_sim(j) = phi_1*kk_sim(j-1) + phi_2*kk_sim(j-2) + n_ka*aleatorios(j-1,jj);
    end
    data_kk_sim = [data_kk_sim kk_sim]; 
end
% ======Producto 
% empieza en y(1)
data_y_sim = alpha*data_a_sim + (1-alpha)*data_kk_sim(1:periodo_final,:); 
% ======Consumo
% empieza en c(1)
data_c_sim = n_ck*data_kk_sim(1:periodo_final,:) + n_ca*data_a_sim;
% ======Inversi�n
% empieza en i(1)
n_ik=(y_ss/i_ss)*(1-alpha - (c_ss/y_ss)*n_ck); %par�metro n_ik
n_ia=(y_ss/i_ss)*(alpha - (c_ss/y_ss)*n_ca); %par�metro n_ia
for jj=1:n_simu
    for j=1:1:periodo_final
    data_i_sim(j,jj) = n_ik*data_kk_sim(j,jj) + n_ia*data_a_sim(j,jj);
    end
end
% ======Tasa de inter�s real bruta
% empieza en r(1)
data_R_sim = lambda_3*(data_a_sim - data_kk_sim(1:periodo_final,:));
% Guardando las simulaciones en una estructura
name_sim = {'y_sim','k_sim','c_sim','i_sim','R_sim','a_sim'};
simul_model = {data_y_sim, data_kk_sim(1:periodo_final,:), data_c_sim, data_i_sim, data_R_sim,data_a_sim};
for i=1:6
    eval(['modelo.simulaciones.',char(name_sim{i}),'=simul_model{i}',';']);
end
%% [5] Componente c�clico: filtro HP
ss= hpfilter(data_y_sim);
hp = {'tendencia','ciclo'};
name = {'y','k','c','i','R','a'};
for j =1:6
    eval(['modelo.filtrohp.',char(hp{1}),'_',char(name{j}),' = hpfilter(simul_model{j})',';']);
    eval(['modelo.filtrohp.',char(hp{2}),'_',char(name{j}),' = simul_model{j} - hpfilter(simul_model{j})',';']);
end
%% [6] Estad�sticos del componente c�clico
name_statistic = {'media', 'varianzas', 'correlacionpbi','std'};
    for j=1:6
        eval(['modelo.estadisticas.',char(name_statistic{1}),'.',char(name{j}), '= mean(mean(modelo.filtrohp.ciclo','_',char(name{j}),'))',';']);
        % Para la desviaci�n est�ndar se usa la funci�n: std
        eval(['modelo.estadisticas.',char(name_statistic{4}),'.',char(name{j}), '= mean(std(modelo.filtrohp.ciclo','_',char(name{j}),'))',';']);
        eval(['modelo.estadisticas.',char(name_statistic{2}),'.',char(name{j}), '= mean(var(modelo.filtrohp.ciclo','_',char(name{j}),'))',';']);
            for m=1:n_simu
                % (1) se calcula la correlaci�n entre la 1era columna de
                % "a" con la 1era columna de "y".
            eval(['corre_',char(name{j}),'_y','= corrcoef(modelo.filtrohp.ciclo','_',char(name{j}),'(:,m)',',modelo.filtrohp.ciclo','_',char(name{1}),'(:,m)',')',';']);
                % (2) se guarda dicha correlaci�n en "a_y" (nota: la funci�n corrcoef brinda una matriz 2x2, 
                % siendo la diagonal secundaria la correlaci�n)
            eval([char(name{j}),'_y(m)','=corre_',char(name{j}),'_y','(1,2)',';']);
                % (3) se calcula la media de las correlaciones guardadas en
                % "a_y"
            eval(['modelo.estadisticas.',char(name_statistic{1}),'.',char(name{j}), '= mean(',char(name{j}),'_y)',';']);
            end
    end
%% [7] Distribuciones
%Distribuci�n de la desviaci�n est�ndar
figure('Name','Distribuciones (desviaci�n est�ndar)');
name_var = {'Producto','Capital','Consumo','Inversi�n','Tasa de inter�s real', 'Productividad'};
for i=1:6
subplot(2,3,i)
hist(std(eval(['modelo.filtrohp.ciclo','_',char(name{i})])))
title(name_var{i});
end;
orient landscape
saveas(gcf,'distribuciones_std1','pdf');
%% [8] Valores (estad�sticos) del modelo te�rico
% media de la distribuci�n (de la desviaci�n est�ndar)
mean_d_y = mean(std(modelo.filtrohp.ciclo_y));
mean_d_c = mean(std(modelo.filtrohp.ciclo_c));
mean_d_i = mean(std(modelo.filtrohp.ciclo_i));
% desviaci�n est�ndar de la distribuci�n (de la desviaci�n est�ndar)
std_d_y = std(std(modelo.filtrohp.ciclo_y));
std_d_c = std(std(modelo.filtrohp.ciclo_c));
std_d_i = std(std(modelo.filtrohp.ciclo_i));

    
