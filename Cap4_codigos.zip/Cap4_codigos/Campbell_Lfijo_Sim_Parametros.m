%% Modelo de Campbell (1994)
%{
Modelo A: trabajo fijo
Autor: Hamilton Galindo
Fecha(update): Setiembre 2013, diciembre 2016, enero 2017
%}
%% Descripci�n
% Este m-file simula los par�metros de soluci�n: n_ck, n_ca, n_kk, n_ka
%{ 
Las secciones de  este m-file son:
 [1] Calibraci�n
 [2] C�lculo del estado estacionario (SS)
 [3] Simulaci�n de las elasticidades
 [4] Graficando las elasticidades
 [5] Graficando n_ca en 3D (funci�n de sigma y phi)
%}
%% [1] Calibraci�n
R_ss = exp(0.015); % (Campbell supone: r = ln(R_ss) = 0.015, el cual rinde 6% anual)
alpha = 0.667;
delta = 0.025; % (10% anual)
beta = 1/R_ss;
%% [2] C�lculo del estado estacionario (SS)
r_ss = R_ss - (1 - delta);
a_ss = 1;
k_ss = a_ss*(r_ss/(1-alpha))^(-1/alpha);
y_ss = a_ss^(alpha)*k_ss^(1-alpha);
i_ss = delta*k_ss;
c_ss = y_ss - i_ss;
lambda_1 = (1-delta) + delta*(1-alpha)*y_ss/i_ss; %1.0151
lambda_2 = delta*alpha*y_ss/i_ss; 
lambda_3 = alpha*r_ss/R_ss;
%% [3] Simulaci�n de las elasticidades
Q2 = 1 -lambda_1 - lambda_2;
sigma = 0:0.1:10; % vector de valores de sigma (elasticidad de sustituci�n intertemporal del consumo)
% para el gr�fico 3D considerar: sigma = [0:0.5:20]
phi = 0:0.1:1; % vector de valores de phi (persistencia del choque)
% para el gr�fico 3D considerar: phi = [0:0.025:1]
Q11 = [];
Q00 = [];
n_ck1 = [];
n_ca1 = [];
n_ka1 = [];
n_kk1 = [];
matriz_n_ca1 = [];
matriz_n_ka1 = [];
for i=1:size(sigma,2)
Q1 = lambda_1 - 1 + sigma(i)*lambda_3*Q2;
Q0 = sigma(i)*lambda_3*lambda_1;
n_ck = (1/(2*Q2))*(-Q1 - sqrt(Q1^2 - 4*Q0*Q2));
n_kk = lambda_1 + (1 -lambda_1 - lambda_2)*n_ck;
for j=1:size(phi,2)
    n_ca = (-n_ck*lambda_2 + sigma(i)*lambda_3*(phi(j) - lambda_2))/(phi(j) - 1 + Q2*(n_ck + sigma(i)*lambda_3));
    n_ka = lambda_2 + (1 -lambda_1 - lambda_2)*n_ca;
    n_ca1 = [n_ca1 n_ca];
    n_ka1 = [n_ka1 n_ka];
end
matriz_n_ca1(i,:) = n_ca1;
matriz_n_ka1(i,:) = n_ka1;
n_ca1 = [];
n_ka1 = [];
Q11 = [Q11 Q1]; 
Q00 = [Q00 Q0];
n_ck1 = [n_ck1 n_ck];
n_kk1 = [n_kk1 n_kk];
end
%% [4] Graficando las elasticidades
figure('Name','Par�metros');
subplot(2,2,1)
plot(sigma,n_ck1,'LineWidth',1.5);
grid on;
title('\eta_{ck}');
xlabel('Elasticidad de sustituci�n intertemporal del consumo (\sigma)');
subplot(2,2,2)
plot(sigma,n_kk1,'LineWidth',1.5)
grid on;
title('\eta_{kk}');
xlabel('Elasticidad de sustituci�n intertemporal del consumo (\sigma)');
subplot(2,2,3)
plot(sigma,matriz_n_ca1(:,1),sigma,matriz_n_ca1(:,5),sigma,matriz_n_ca1(:,9),'LineWidth',1.5);
grid on;
legend('\phi=0','\phi=0.4','\phi=0.8','location','south','Orientation','horizontal')
legend('boxoff');
title('\eta_{ca}');
xlabel('Elasticidad de sustituci�n intertemporal del consumo (\sigma)');
subplot(2,2,4)
plot(sigma,matriz_n_ka1(:,1),sigma,matriz_n_ka1(:,5),sigma,matriz_n_ka1(:,9),'LineWidth',1.5);
grid on;
legend('\phi=0','\phi=0.4','\phi=0.8','location','south','Orientation','horizontal')
legend('boxoff');
title('\eta_{ka}');
xlabel('Elasticidad de sustituci�n intertemporal del consumo (\sigma)');
orient landscape
saveas(gcf,'par�metros','pdf');
%% [5] Graficando n_ca en 3D (funci�n de sigma y phi)
[S,P] = meshgrid(sigma,phi);
figure('Name','Gr�fico n_{ca}')
subplot(2,1,1)
surf(S,P,matriz_n_ca1')
colormap([0 0 1;0.9 0 0])
colorbar
xlabel('Elasticidad de sustituci�n del consumo (\sigma)');
ylabel('Persistencia del choque (\phi)');
zlabel('Elasticidad del consumo a la productividad: \eta_{ca}');
subplot(2,1,2)
surf(S,P,matriz_n_ka1')
colormap([0 0 1;0.9 0 0])
colorbar
xlabel('Elasticidad de sustituci�n del consumo (\sigma)');
ylabel('Persistencia del choque (\phi)');
zlabel('Elasticidad del capital a la productividad: \eta_{ka}');