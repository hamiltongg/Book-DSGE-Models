%% Modelo de Campbell (1994)
%{ 
Modelo A: trabajo fijo
Autor: Hamilton Galindo
Fecha(update): julio 2013, julio 2015, diciembre 2016, enero 2017
%}
%% Descripci�n
%{ 
Las secciones de  este m-file son:
 [1] Calibraci�n
 [2] C�lculo del estado estacionario (SS)
 [3] C�lculo de los coeficientes de la soluci�n (m�todo coeficientes indeterminados)
 [4] C�lculo de la funci�n impulso-respuesta (IRF): variables log-lineales
 [5] C�lculo de la funci�n impulso-respuesta (IRF): variables en niveles 
 [6] Simulaci�n de las variables (series de tiempo ARMA(p,q))
 [7] Componente c�clico de las variables simuladas: filtro HP 
 [8] Estad�sticos del componente c�clico (modelo te�rico)
%}
%% [1] Calibraci�n 
% Calibraci�n para un modelo trimestral 
% g = 0.005; % (2% anual)
R_ss = exp(0.015); % (Campbell supone: r = ln(R_ss) = 0.015, el cual rinde 6% anual)
alpha = 0.667;
delta = 0.025; %(10% anual)
phi = 0.5; %persistencia del choque
sigma = 10; %elasticidad de sustituci�n intertemporal
%% [2] C�lculo de estado estacionario 
beta = 1/R_ss;
r_ss = R_ss - (1 - delta);
a_ss = 1;
k_ss = a_ss*(r_ss/(1-alpha))^(-1/alpha);
y_ss = a_ss^(alpha)*k_ss^(1-alpha);
i_ss = delta*k_ss;
c_ss = y_ss - i_ss;
%% Comparaci�n con modelo de Campbell
% ecuaci�n 2.10 del paper del Campbell (considerando g = 0)
ratio_cy_campbell = 1 - (1-alpha)*(0 + delta)/(log(R_ss) + delta); 
% ratio_cy_campbell = 0.7919
ratio_cy_modelo = c_ss/y_ss;
% ratio_cy_modelo = 0.7925
%% C�lculo de lamba (1, 2 y 3)
lambda_1 = (1-delta) + delta*(1-alpha)*y_ss/i_ss; %1.0151
% coincide con el valor de lambda_1 del paper (eq 2.14) cuando g=0 --> 1.0150
lambda_2 = delta*alpha*y_ss/i_ss; %0.0803
% coincide con el valor de lambda_2 del paper (eq 2.14) cuando g=0 --> 0.08
% (check el paper, porque puede haber un error de tip�o en lambda_2 del paper)
lambda_3 = alpha*r_ss/R_ss;
% coincide con el paper (0.0264), ver eq 2.16
%% [3] M�todo de coeficientes indeterminados
Q2 = 1 -lambda_1 - lambda_2;
Q1 = lambda_1 - 1 + sigma*lambda_3*Q2;
Q0 = sigma*lambda_3*lambda_1;
n_ck = (1/(2*Q2))*(-Q1 - sqrt(Q1^2 - 4*Q0*Q2));
n_ca = (-n_ck*lambda_2 + sigma*lambda_3*(phi - lambda_2))/(phi - 1 + Q2*(n_ck + sigma*lambda_3));
n_kk = lambda_1 + (1 -lambda_1 - lambda_2)*n_ck;
n_ka = lambda_2 + (1 -lambda_1 - lambda_2)*n_ca;
%% Ecuaci�n en diferencias
% Capital
% Coef. del k(t+1) AR(2)
phi_1 = phi + n_kk;
phi_2 = -phi*n_kk;
% Raices del polinomio caracter�stico
y1 = (1/(2*phi_2))*(-phi_1 + sqrt(phi_1^2 + 4*phi_2));
y2 = (1/(2*phi_2))*(-phi_1 - sqrt(phi_1^2 + 4*phi_2));
% Coef. de la factorizaci�n en L
theta_1 = 1/y1;
theta_2 = 1/y2;
% Coef. de la versi�n MA(infinito) del AR(2)
psi_total = zeros(31,1);
periodo_final = 200;
for k=0:periodo_final;
    psi = [];
  for j=0:k
     psi_parcial = (theta_1^j)*(theta_2^(k-j));
     psi = [psi psi_parcial];
  end
  psi_total(k+1) = sum(psi);
end
%% [4] Funci�n impulso-respuesta: variables log-lineales
% IRF del capital: obteniendo IRF del K desde su forma MA(infinito)
choque = 1; %(e_1 = 1). Se supone que la desviaci�n estand�r de "e" es igual a 1. 
e1 = choque;
coef = [1;psi_total(1:periodo_final,:)];
e0 = 0;
errores = [e0;e1*ones(periodo_final,1)];
k_irf = n_ka*coef.*errores;
time = [0:1:periodo_final]';
figure('Name','IRF del capital');
plot(time,k_irf);
grid;
title('Capital')
%% IRF de las dem�s variables del modelo
e = zeros(periodo_final+1,1);
e(1) = choque;
%============[productividad]
a = zeros(periodo_final,1);
a_0 = 0; %a(0) = 0
a_1 = 0; %a(-1) = 0
a(1) = phi*a_0 + e(1);
for j=2:200
    a(j) = phi*a(j-1) + e(j);
end
a_irf = [a_0; a]; % 201 filas (t=0 hasta 200)
%============[capital]
% [obteniendo IRF del K desde 
% su forma AR(2)]
k = zeros(periodo_final+1,1);
k_1 = 0; %k(-1) = 0
k_0 = 0; %k(0) = 0
k(1) = phi_1*k_0 + phi_2*k_1 + n_ka*e0;
k(2) = phi_1*k(1) + phi_2*k_0 + n_ka*e(1);
% Hacemos j hasta 201 por la inversi�n
for j=3:201
    k(j) = phi_1*k(j-1) + phi_2*k(j-2) + n_ka*e(j-1);
end
% K_irf es el mismo que el obtenido
% por la versi�n MA(infinito)
%============[producto, consumo, tasa de inter�s e inversi�n]
y = zeros(periodo_final,1);
c = zeros(periodo_final,1);
R = zeros(periodo_final,1);
i = zeros(periodo_final,1);
for j=1:200
    y(j) = alpha*a(j) + (1-alpha)*k(j);
    c(j) = n_ck*k(j) + n_ca*a(j);
    R(j) = lambda_3*(a(j) - k(j));
    i(j) = (y_ss/i_ss)*(y(j) - (c_ss/y_ss)*c(j)); % sale de la ecuaci�n de equilibrio de mercado (esto debe de quedar en funci�n a "k" y "a")
end
y_0 = 0; %t=0
c_0 = 0; %t=0
R_0 = 0; %t=0
i_0 = 0; %t=0
y_irf = [y_0; y]; % 201 filas (t=0 hasta 200)
c_irf = [c_0; c]; % 201 filas (t=0 hasta 200)
R_irf = [R_0; R]; % 201 filas (t=0 hasta 200)
i_irf = [i_0; i]; % 201 filas (t=0 hasta 200)
%% Graficando los IRF's (de las variables log-lineales)
figure('Name','IRF de variables log-lineal');
irf = [y_irf k_irf c_irf i_irf R_irf a_irf];
variable_name = {'Producto' 'Capital' 'Consumo' 'Inversi�n' 'Tasa de inter�s real bruta' 'Productividad'};
nvar = size(variable_name,2);
% Gr�fica desde t=1
for i= 1:nvar
subplot(2,3,i)
plot(time,irf(:,i),'LineWidth', 1.5);
title(variable_name{i});
grid;
end
orient landscape
saveas(gcf,'IRF_variables_loglineal1','pdf');

%% [5] Funci�n impulso-respuesta: variables en niveles
% Calculando la IRF de las variables en niveles
y_irf_n = y_ss*exp(y_irf);
k_irf_n = k_ss*exp(k_irf);
c_irf_n = c_ss*exp(c_irf);
i_irf_n = i_ss*exp(i_irf);
R_irf_n = R_ss*exp(R_irf);
a_irf_n= a_ss*exp(a_irf);
irf_niveles = [y_irf_n k_irf_n c_irf_n i_irf_n R_irf_n a_irf_n];
% Calculando el estado estacionario como una l�nea para graficar
ss = [y_ss*ones(size(y_irf_n,1),1)...
    k_ss*ones(size(y_irf_n,1),1)...
    c_ss*ones(size(y_irf_n,1),1)...
    i_ss*ones(size(y_irf_n,1),1)...
    R_ss*ones(size(y_irf_n,1),1)...
    a_ss*ones(size(y_irf_n,1),1)];
variable_name = {'Producto' 'Capital' 'Consumo' 'Inversi�n' 'Tasa de inter�s real bruta' 'Productividad'};
nvar = size(variable_name,2);
%% Graficando los IRF's (de las variables en niveles)
figure('Name','IRF de variables niveles');
% Gr�fica desde t=1
for i= 1:nvar
subplot(2,3,i)
plot(time, ss(:,i), time,irf_niveles(:,i),'LineWidth', 1.5);
title(variable_name{i});
grid;
end
orient landscape
saveas(gcf,'IRF_variables_niveles1','pdf');

% Gr�fica del consumo, producto e inversi�n (IRFs):
% comparaci�n de las variables log-lineal vs en niveles
figure('Name','IRF variables en niveles')
subplot(1,2,1)
plot(time, irf_niveles(:,1),time, irf_niveles(:,3),time, irf_niveles(:,4),'LineWidth', 1.5);
title('Variables en niveles');
hold on;
plot(time, ss(:,1), time, ss(:,3), time, ss(:,4),'linestyle','--');
legend('Producto','Consumo','Inversi�n','SS_{Producto}','SS_{Consumo}','SS_{Inversi�n}');
hold off;
subplot(1,2,2)
plot(time, irf(:,1),time, irf(:,3),time, irf(:,4),'LineWidth', 1.5);
title('Variables log-lineal');
legend('Producto','Consumo','Inversi�n')
orient landscape
saveas(gcf,'IRF_3variables','pdf');
%% [6] Simulaci�n de las variables (series de tiempo ARMA(p,q))
%% Simulaci�n del K(t+1)
% desv_stand = choque;
% e = desv_stand.*randn(periodo_final,1);
% k_sim = [k1 k2 k3 ...k200]'
e = randn(periodo_final,1);
k_sim0 = 0; %K(0) = 0
k_sim1 = 0; %k(-1) = 0
% Se hace hasta periodo_final+1 debido a la INVERSI�N
k_sim = zeros(periodo_final+1,1); %no incluye el t=0
k_sim(1) = phi_1*k_sim0 + phi_2*k_sim1 + n_ka*e0;
k_sim(2) = phi_1*k_sim(1) + phi_2*k_sim0 + n_ka*e(1);
for j = 3:1:periodo_final+1
    k_sim(j) = phi_1*k_sim(j-1) + phi_2*k_sim(j-2) + n_ka*e(j-1);
end
figure('Name','Simulaci�n del capital')
plot(k_sim(1:periodo_final),'LineWidth', 1.5);
title('Capital');
grid;

%% Simulaci�n de las dem�s variables del modelo
% Productividad
a_sim0 = 0; %a(0) = 0
a_sim = zeros(periodo_final,1); %desde t=1: a_1, a_2...
a_sim(1)= phi*a_sim0 + e(1);%a(1) = n�mero aleatorio
for j = 2:1:periodo_final
    a_sim(j) = phi*a_sim(j-1) + e(j);
end
% Producto
y_sim0 = alpha*a_sim0 + (1-alpha)*k_sim0;
y_sim = alpha*a_sim + (1-alpha)*k_sim(1:periodo_final);
% Consumo
c_sim0 = n_ck*k_sim0 + n_ca*a_sim0;
c_sim = n_ck*k_sim(1:periodo_final) + n_ca*a_sim;
% Inversi�n
n_ik=(y_ss/i_ss)*(1-alpha - (c_ss/y_ss)*n_ck); %par�metro n_ik
n_ia=(y_ss/i_ss)*(alpha - (c_ss/y_ss)*n_ca); %par�metro n_ia
i_sim0 = n_ik*k_sim0 + n_ia*a_sim0;
i_sim = zeros(periodo_final,1);
for j=1:1:periodo_final
i_sim(j) = n_ik*k_sim(j) + n_ia*a_sim(j);
end
% Tasa de inter�s bruta
R_sim0 = lambda_3*(a_sim0 - k_sim0);
R_sim = lambda_3*(a_sim - k_sim(1:periodo_final));
%% Gr�ficos de las simulaci�n de variables
figure('Name','Simulaci�n de variables');
data = [y_sim k_sim(1:periodo_final) c_sim i_sim R_sim a_sim];
%variable_name = {'Producto' 'Capital' 'Consumo' 'Inversi�n' 'Tasa de inter�s' 'Productividad'};
%nvar = size(variable_name,2);
% Gr�fica desde t=1
for i= 1:nvar
subplot(2,3,i)
plot(data(:,i),'LineWidth', 1.5);
title(variable_name{i});
grid;
end
orient landscape
saveas(gcf,'Sim_variables_loglineal','pdf');

%% [7] Componente c�clico de las variables simuladas: filtro HP 
[trend,cycle] = hpfilter(data,1600);
% Gr�fica: trend, cycle y data simulada
variable_name1 ={'y' 'k' 'c' 'i' 'R' 'a'};
figure('Name', 'Tendencia y ciclo por variable')
for i=1:size(data,2)
subplot(2,3,i)
plot(time(2:201), data(:,i),time(2:201), trend(:,i),'--',time(2:201), cycle(:,i),'-.','LineWidth', 1.5)
title(variable_name{i});
leg = legend(variable_name1{i}, 'Tendencia', 'Ciclo');
set(leg, 'orientation','horizontal');
set(leg, 'location', 'south');
set(leg, 'FontSize', 7); 
legend('boxoff');
end;
orient landscape
saveas(gcf,'trend_cycle4','pdf');
%% [8 ]Estad�sticos del componente c�clico (modelo te�rico)
estadisticos.medias = mean(cycle);
estadisticos.var_cov = cov(cycle);
estadisticos.correlacion = corrcoef(cycle);

%% Evaluando: expresi�n que relaciona los valores de la funci�n impulso-respuesta de las variables en niveles
E = log(y_ss) - (c_ss/y_ss)*log(c_ss)- (i_ss/y_ss)*log(i_ss) + (c_ss/y_ss)*log(irf_niveles(10,3)) + (i_ss/y_ss)*log(irf_niveles(10,4)) - log(irf_niveles(10,1)); % "E" deber�a ser igual a cero para cualquier fila. 
% La columna 3 y 4 de irf_niveles corresponde al consumo y la inversi�n respectivamente. 
 
