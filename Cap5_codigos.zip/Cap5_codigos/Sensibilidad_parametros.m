%% Modelo de Campbell (1994)
%{ 
Modelo A: trabajo variable
Autor: Hamilton Galindo
Fecha(update): junio 2017
%}
%% Descripci�n
%{ 
Las secciones de  este m-file son:
 [1] Simulaci�n de los coeficientes de la soluci�n: delta
      (tasa de depreciaci�n)
 [2] Simulaci�n de los coeficientes de la soluci�n: alpha
      (participaci�n del capital en la renta nacional)
 [3] Simulaci�n de los coeficientes de la soluci�n: gamma_n
      (inversa de elasticidad de Frisch)
 [4] Simulaci�n de los coeficientes de la soluci�n: phi
      (persistencia del choque)
%}

%% [1] Simulaci�n de los coeficientes: delta
% delta: tasa de depreciaci�n
deltas = [0.1:0.1:1];
for j = 1:size(deltas,2)
% Par�metros
theta = 2; % corresponde a epsilon=2/3, tomado de Prescott (1986)
beta = 0.984;
delta = deltas(j);       %(= 1 para el modelo de Long y Plosser, 1983)
gamma = 1;          % ESI del consumo (=1 hace que u(c) = log c)
gamma_n = 0.25; % inversa elasticidad de Frisch (de la oferta de trabajo)
alpha = 0.333;      %participaci�n del capital en la renta nacional
phi = 0.95;            %persistencia del choque
sigma = 0.01;        %des est del choque
% Estado estacionario 
a_ss = 1;
r_ss = 1/beta - (1-delta);
yk = (r_ss/alpha);                 %y/k
hk = (yk/a_ss)^(1/(1-alpha)); %h/k
w_ss= (1-alpha)*yk/hk;
ik = delta;                              %i/k
ck = yk - ik;
h0 = 0.4;
h_ss= fsolve(@(h_ss) trabajo_ss(h_ss,delta,alpha,gamma_n),h0); % se llama a la funci�n trabajo_ss.m (tiene que estar en la misma carpeta)
k_ss = h_ss*(hk)^(-1);
i_ss = ik*k_ss;
y_ss = yk*k_ss;
c_ss = y_ss - i_ss;
% Coeficientes preliminares de la soluci�n
m1 = gamma_n*(h_ss/(1-h_ss));
m2 = (1 + m1)/(m1 + alpha);
m3 = alpha*(1 + m1)/(m1 + alpha) + (i_ss/(y_ss*delta))*(1 - delta);
m4 = (c_ss/y_ss) + (1 - alpha)/(m1 + alpha);
m5 = i_ss/(y_ss*delta);
n1 = 1+ beta*r_ss*(1 - alpha)/(m1 + alpha);
n2 = beta*r_ss*(1 + m1)/(m1 + alpha);
n3 = beta*r_ss - beta*r_ss*((1 + m1)/(m1 + alpha))*alpha;
% Ecuaci�n cuadr�tica en n_kk:
% a*n_kk^2 + b*n_kk + c
a = n1*m5;
b = -(n1*m3 + n3*m4 + m5);
c= m3;
% Coeficientes del capital y del consumo
%-----------------------------------------------------
% c�lculo de las 2 raices de la Ecuaci�n cuadr�tica en n_kk:
n_kk1(j) = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c)); % = 1.0897
n_kk2(j) = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));  % = 0.9326
n_ck(j) = (m3 - m5*n_kk2(j))/m4;
n_ka(j) = (phi*n2 + (m2/m4)*(1 - phi*n1))/((m5/m4)*(1 - phi*n1) + n1*n_ck(j) +n3);
n_ca(j) = (m2 - m5*n_ka(j))/m4;
% Coeficientes del producto
%-----------------------------------------------------
% Producto: y = n_yk*k + n_ya*a
n_ya(j) = ((1 + m1)/(m1 + alpha))*(1 - (1-alpha)*n_ca(j)/(1 + m1));
n_yk(j) = ((1 + m1)/(m1 + alpha))*(alpha - (1-alpha)*n_ck(j)/(1 + m1));
% Coeficientes del trabajo
%-----------------------------------------------------
%Trabajo: h = n_hk*k + n_ha*a
n_ha(j) = (n_ya(j) - n_ca(j))/(1 + m1);
n_hk(j) = (n_yk(j) - n_ck(j))/(1 + m1);
% Coeficientes del salario
%-----------------------------------------------------
%Salario: h = n_wk*k + n_wa*a
n_wa(j) = n_ya(j) - n_ha(j);
n_wk(j) = n_yk(j) - n_hk(j);
% Coeficientes de la inversi�n
%-----------------------------------------------------
%Inversi�n: i = n_ik*k + n_ia*a
n_ia(j) = (y_ss/i_ss)*(n_ya(j) - (c_ss/y_ss)*n_ca(j));
n_ik(j) = (y_ss/i_ss)*(n_yk(j) - (c_ss/y_ss)*n_ck(j));
% Coeficientes de la tasa de inter�s
%-----------------------------------------------------
%Tasa de inter�s: r = n_rk*k + n_ra*a
n_ra(j) = n_ya(j);
n_rk(j) = n_yk(j) - 1;
end;

% Gr�fico: Capital
%------------------------------
figure('Name','[1A] Simulaci�n de los coeficientes del capital (n_kk, n_ka)')
subplot(2,2,1)
plot(deltas,n_kk1,'LineWidth',1.5);
title('n_{kk1}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,2)
plot(deltas,n_kk2,'LineWidth',1.5);
title('n_{kk2}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,3:4)
plot(deltas,n_ka,'LineWidth',1.5);
title('n_{ka}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

% Gr�fico: Consumo - Inversi�n
%------------------------------
figure('Name','[1B] Simulaci�n de los coeficientes del consumo-Inversi�n (n_ck, n_ca, n_ik, n_ia)')
subplot(2,2,1)
plot(deltas,n_ck,'LineWidth',1.5);
title('n_{ck}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,2)
plot(deltas,n_ca,'LineWidth',1.5);
title('n_{ca}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,3)
plot(deltas,n_ik,'LineWidth',1.5);
title('n_{ik}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,4)
plot(deltas,n_ia,'LineWidth',1.5);
title('n_{ia}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

% Gr�fico: Producto - Tasa de inter�s
%------------------------------
figure('Name','[1C] Simulaci�n de los coeficientes del producto-tasa de inter�s (n_yk, n_ya,n_ik, n_ia)')
subplot(2,2,1)
plot(deltas,n_yk,'LineWidth',1.5);
title('n_{yk}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,2)
plot(deltas,n_ya,'LineWidth',1.5);
title('n_{ya}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,3)
plot(deltas,n_rk,'LineWidth',1.5);
title('n_{rk}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,4)
plot(deltas,n_ra,'LineWidth',1.5);
title('n_{ra}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

% Gr�fico: Trabajo - Salario
%------------------------------
figure('Name','[1D] Simulaci�n de los coeficientes del trabajo-salario (n_hk, n_ha,n_wk, n_wa)')
subplot(2,2,1)
plot(deltas,n_hk,'LineWidth',1.5);
title('n_{hk}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,2)
plot(deltas,n_ha,'LineWidth',1.5);
title('n_{ha}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,3)
plot(deltas,n_wk,'LineWidth',1.5);
title('n_{wk}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

subplot(2,2,4)
plot(deltas,n_wa,'LineWidth',1.5);
title('n_{wa}');
xlabel('Tasa de depreciaci�n (\delta)')
grid;

clear all;

%% [2] Simulaci�n de los coeficientes: alpha
% alpha: participaci�n del capital en la renta nacional
alphas = [0.1:0.1:0.9];
for j = 1:size(alphas,2)
% Par�metros
theta = 2; % corresponde a epsilon=2/3, tomado de Prescott (1986)
beta = 0.984;
delta = 0.025;       %(= 1 para el modelo de Long y Plosser, 1983)
gamma = 1;          % ESI del consumo (=1 hace que u(c) = log c)
gamma_n = 0.25; % inversa elasticidad de Frisch (de la oferta de trabajo)
alpha = alphas(j);      %participaci�n del capital en la renta nacional
phi = 0.95;            %persistencia del choque
sigma = 0.01;        %des est del choque
% Estado estacionario 
a_ss = 1;
r_ss = 1/beta - (1-delta);
yk = (r_ss/alpha);                 %y/k
hk = (yk/a_ss)^(1/(1-alpha)); %h/k
w_ss= (1-alpha)*yk/hk;
ik = delta;                              %i/k
ck = yk - ik;
h0 = 0.4;
h_ss= fsolve(@(h_ss) trabajo_ss(h_ss,delta,alpha,gamma_n),h0); % se llama a la funci�n trabajo_ss.m (tiene que estar en la misma carpeta)
k_ss = h_ss*(hk)^(-1);
i_ss = ik*k_ss;
y_ss = yk*k_ss;
c_ss = y_ss - i_ss;
% Coeficientes preliminares de la soluci�n
m1 = gamma_n*(h_ss/(1-h_ss));
m2 = (1 + m1)/(m1 + alpha);
m3 = alpha*(1 + m1)/(m1 + alpha) + (i_ss/(y_ss*delta))*(1 - delta);
m4 = (c_ss/y_ss) + (1 - alpha)/(m1 + alpha);
m5 = i_ss/(y_ss*delta);
n1 = 1+ beta*r_ss*(1 - alpha)/(m1 + alpha);
n2 = beta*r_ss*(1 + m1)/(m1 + alpha);
n3 = beta*r_ss - beta*r_ss*((1 + m1)/(m1 + alpha))*alpha;
% Ecuaci�n cuadr�tica en n_kk:
% a*n_kk^2 + b*n_kk + c
a = n1*m5;
b = -(n1*m3 + n3*m4 + m5);
c= m3;
% Coeficientes del capital y del consumo
%-----------------------------------------------------
% c�lculo de las 2 raices de la Ecuaci�n cuadr�tica en n_kk:
n_kk1(j) = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c)); % = 1.0897
n_kk2(j) = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));  % = 0.9326
n_ck(j) = (m3 - m5*n_kk2(j))/m4;
n_ka(j) = (phi*n2 + (m2/m4)*(1 - phi*n1))/((m5/m4)*(1 - phi*n1) + n1*n_ck(j) +n3);
n_ca(j) = (m2 - m5*n_ka(j))/m4;
% Coeficientes del producto
%-----------------------------------------------------
% Producto: y = n_yk*k + n_ya*a
n_ya(j) = ((1 + m1)/(m1 + alpha))*(1 - (1-alpha)*n_ca(j)/(1 + m1));
n_yk(j) = ((1 + m1)/(m1 + alpha))*(alpha - (1-alpha)*n_ck(j)/(1 + m1));
% Coeficientes del trabajo
%-----------------------------------------------------
%Trabajo: h = n_hk*k + n_ha*a
n_ha(j) = (n_ya(j) - n_ca(j))/(1 + m1);
n_hk(j) = (n_yk(j) - n_ck(j))/(1 + m1);
% Coeficientes del salario
%-----------------------------------------------------
%Salario: h = n_wk*k + n_wa*a
n_wa(j) = n_ya(j) - n_ha(j);
n_wk(j) = n_yk(j) - n_hk(j);
% Coeficientes de la inversi�n
%-----------------------------------------------------
%Inversi�n: i = n_ik*k + n_ia*a
n_ia(j) = (y_ss/i_ss)*(n_ya(j) - (c_ss/y_ss)*n_ca(j));
n_ik(j) = (y_ss/i_ss)*(n_yk(j) - (c_ss/y_ss)*n_ck(j));
% Coeficientes de la tasa de inter�s
%-----------------------------------------------------
%Tasa de inter�s: r = n_rk*k + n_ra*a
n_ra(j) = n_ya(j);
n_rk(j) = n_yk(j) - 1;
end;

% Gr�fico: Capital
%------------------------------
figure('Name','[2A] Simulaci�n de los coeficientes del capital (n_kk, n_ka)')
subplot(2,2,1)
plot(alphas,n_kk1,'LineWidth',1.5);
title('n_{kk1}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,2)
plot(alphas,n_kk2,'LineWidth',1.5);
title('n_{kk2}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,3:4)
plot(alphas,n_ka,'LineWidth',1.5);
title('n_{ka}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

% Gr�fico: Consumo - Inversi�n
%------------------------------
figure('Name','[2B] Simulaci�n de los coeficientes del consumo-Inversi�n (n_ck, n_ca, n_ik, n_ia)')
subplot(2,2,1)
plot(alphas,n_ck,'LineWidth',1.5);
title('n_{ck}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,2)
plot(alphas,n_ca,'LineWidth',1.5);
title('n_{ca}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,3)
plot(alphas,n_ik,'LineWidth',1.5);
title('n_{ik}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,4)
plot(alphas,n_ia,'LineWidth',1.5);
title('n_{ia}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

% Gr�fico: Producto - Tasa de inter�s
%------------------------------
figure('Name','[2C] Simulaci�n de los coeficientes del producto-tasa de inter�s (n_yk, n_ya,n_ik, n_ia)')
subplot(2,2,1)
plot(alphas,n_yk,'LineWidth',1.5);
title('n_{yk}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,2)
plot(alphas,n_ya,'LineWidth',1.5);
title('n_{ya}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,3)
plot(alphas,n_rk,'LineWidth',1.5);
title('n_{rk}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,4)
plot(alphas,n_ra,'LineWidth',1.5);
title('n_{ra}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

% Gr�fico: Trabajo - Salario
%------------------------------
figure('Name','[2D] Simulaci�n de los coeficientes del trabajo-salario (n_hk, n_ha,n_wk, n_wa)')
subplot(2,2,1)
plot(alphas,n_hk,'LineWidth',1.5);
title('n_{hk}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,2)
plot(alphas,n_ha,'LineWidth',1.5);
title('n_{ha}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,3)
plot(alphas,n_wk,'LineWidth',1.5);
title('n_{wk}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

subplot(2,2,4)
plot(alphas,n_wa,'LineWidth',1.5);
title('n_{wa}');
xlabel('Participaci�n del capital en la renta (\alpha)')
grid;

clear all;

%% [3] Simulaci�n de los coeficientes: gamma_n
% gamma_n: inversa de la elasticidad de Frisch
gammas_n = [0.5:0.5:5];
for j = 1:size(gammas_n,2)
% Par�metros
theta = 2; % corresponde a epsilon=2/3, tomado de Prescott (1986)
beta = 0.984;
delta = 0.025;       %(= 1 para el modelo de Long y Plosser, 1983)
gamma = 1;          % ESI del consumo (=1 hace que u(c) = log c)
gamma_n = gammas_n(j); % inversa elasticidad de Frisch (de la oferta de trabajo)
alpha = 0.333;      %participaci�n del capital en la renta nacional
phi = 0.95;            %persistencia del choque
sigma = 0.01;        %des est del choque
% Estado estacionario 
a_ss = 1;
r_ss = 1/beta - (1-delta);
yk = (r_ss/alpha);                 %y/k
hk = (yk/a_ss)^(1/(1-alpha)); %h/k
w_ss= (1-alpha)*yk/hk;
ik = delta;                              %i/k
ck = yk - ik;
h0 = 0.4;
h_ss= fsolve(@(h_ss) trabajo_ss(h_ss,delta,alpha,gamma_n),h0); % se llama a la funci�n trabajo_ss.m (tiene que estar en la misma carpeta)
k_ss = h_ss*(hk)^(-1);
i_ss = ik*k_ss;
y_ss = yk*k_ss;
c_ss = y_ss - i_ss;
% Coeficientes preliminares de la soluci�n
m1 = gamma_n*(h_ss/(1-h_ss));
m2 = (1 + m1)/(m1 + alpha);
m3 = alpha*(1 + m1)/(m1 + alpha) + (i_ss/(y_ss*delta))*(1 - delta);
m4 = (c_ss/y_ss) + (1 - alpha)/(m1 + alpha);
m5 = i_ss/(y_ss*delta);
n1 = 1+ beta*r_ss*(1 - alpha)/(m1 + alpha);
n2 = beta*r_ss*(1 + m1)/(m1 + alpha);
n3 = beta*r_ss - beta*r_ss*((1 + m1)/(m1 + alpha))*alpha;
% Ecuaci�n cuadr�tica en n_kk:
% a*n_kk^2 + b*n_kk + c
a = n1*m5;
b = -(n1*m3 + n3*m4 + m5);
c= m3;
% Coeficientes del capital y del consumo
%-----------------------------------------------------
% c�lculo de las 2 raices de la Ecuaci�n cuadr�tica en n_kk:
n_kk1(j) = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c)); % = 1.0897
n_kk2(j) = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));  % = 0.9326
n_ck(j) = (m3 - m5*n_kk2(j))/m4;
n_ka(j) = (phi*n2 + (m2/m4)*(1 - phi*n1))/((m5/m4)*(1 - phi*n1) + n1*n_ck(j) +n3);
n_ca(j) = (m2 - m5*n_ka(j))/m4;
% Coeficientes del producto
%-----------------------------------------------------
% Producto: y = n_yk*k + n_ya*a
n_ya(j) = ((1 + m1)/(m1 + alpha))*(1 - (1-alpha)*n_ca(j)/(1 + m1));
n_yk(j) = ((1 + m1)/(m1 + alpha))*(alpha - (1-alpha)*n_ck(j)/(1 + m1));
% Coeficientes del trabajo
%-----------------------------------------------------
%Trabajo: h = n_hk*k + n_ha*a
n_ha(j) = (n_ya(j) - n_ca(j))/(1 + m1);
n_hk(j) = (n_yk(j) - n_ck(j))/(1 + m1);
% Coeficientes del salario
%-----------------------------------------------------
%Salario: h = n_wk*k + n_wa*a
n_wa(j) = n_ya(j) - n_ha(j);
n_wk(j) = n_yk(j) - n_hk(j);
% Coeficientes de la inversi�n
%-----------------------------------------------------
%Inversi�n: i = n_ik*k + n_ia*a
n_ia(j) = (y_ss/i_ss)*(n_ya(j) - (c_ss/y_ss)*n_ca(j));
n_ik(j) = (y_ss/i_ss)*(n_yk(j) - (c_ss/y_ss)*n_ck(j));
% Coeficientes de la tasa de inter�s
%-----------------------------------------------------
%Tasa de inter�s: r = n_rk*k + n_ra*a
n_ra(j) = n_ya(j);
n_rk(j) = n_yk(j) - 1;
end;

% Gr�fico: Capital
%------------------------------
figure('Name','[3A] Simulaci�n de los coeficientes del capital (n_kk, n_ka)')
subplot(2,2,1)
plot(gammas_n,n_kk1,'LineWidth',1.5);
title('n_{kk1}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,2)
plot(gammas_n,n_kk2,'LineWidth',1.5);
title('n_{kk2}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,3:4)
plot(gammas_n,n_ka,'LineWidth',1.5);
title('n_{ka}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

% Gr�fico: Consumo - Inversi�n
%------------------------------
figure('Name','[3B] Simulaci�n de los coeficientes del consumo-Inversi�n (n_ck, n_ca, n_ik, n_ia)')
subplot(2,2,1)
plot(gammas_n,n_ck,'LineWidth',1.5);
title('n_{ck}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,2)
plot(gammas_n,n_ca,'LineWidth',1.5);
title('n_{ca}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,3)
plot(gammas_n,n_ik,'LineWidth',1.5);
title('n_{ik}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,4)
plot(gammas_n,n_ia,'LineWidth',1.5);
title('n_{ia}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

% Gr�fico: Producto - Tasa de inter�s
%------------------------------
figure('Name','[3C] Simulaci�n de los coeficientes del producto-tasa de inter�s (n_yk, n_ya,n_ik, n_ia)')
subplot(2,2,1)
plot(gammas_n,n_yk,'LineWidth',1.5);
title('n_{yk}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,2)
plot(gammas_n,n_ya,'LineWidth',1.5);
title('n_{ya}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,3)
plot(gammas_n,n_rk,'LineWidth',1.5);
title('n_{rk}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,4)
plot(gammas_n,n_ra,'LineWidth',1.5);
title('n_{ra}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

% Gr�fico: Trabajo - Salario
%------------------------------
figure('Name','[3D] Simulaci�n de los coeficientes del trabajo-salario (n_hk, n_ha,n_wk, n_wa)')
subplot(2,2,1)
plot(gammas_n,n_hk,'LineWidth',1.5);
title('n_{hk}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,2)
plot(gammas_n,n_ha,'LineWidth',1.5);
title('n_{ha}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,3)
plot(gammas_n,n_wk,'LineWidth',1.5);
title('n_{wk}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

subplot(2,2,4)
plot(gammas_n,n_wa,'LineWidth',1.5);
title('n_{wa}');
xlabel('Inversa de la elasticidad de Frisch (\gamma_n)')
grid;

clear all;

%% [4] Simulaci�n de los coeficientes: phi
% phi: persistencia del choque 
phis = [0:0.1:1];
for j = 1:size(phis,2)
% Par�metros
theta = 2; % corresponde a epsilon=2/3, tomado de Prescott (1986)
beta = 0.984;
delta = 0.025;       %(= 1 para el modelo de Long y Plosser, 1983)
gamma = 1;          % ESI del consumo (=1 hace que u(c) = log c)
gamma_n = 0.25; % inversa elasticidad de Frisch (de la oferta de trabajo)
alpha = 0.333;      %participaci�n del capital en la renta nacional
phi = phis(j);            %persistencia del choque
sigma = 0.01;        %des est del choque
% Estado estacionario 
a_ss = 1;
r_ss = 1/beta - (1-delta);
yk = (r_ss/alpha);                 %y/k
hk = (yk/a_ss)^(1/(1-alpha)); %h/k
w_ss= (1-alpha)*yk/hk;
ik = delta;                              %i/k
ck = yk - ik;
h0 = 0.4;
h_ss= fsolve(@(h_ss) trabajo_ss(h_ss,delta,alpha,gamma_n),h0); % se llama a la funci�n trabajo_ss.m (tiene que estar en la misma carpeta)
k_ss = h_ss*(hk)^(-1);
i_ss = ik*k_ss;
y_ss = yk*k_ss;
c_ss = y_ss - i_ss;
% Coeficientes preliminares de la soluci�n
m1 = gamma_n*(h_ss/(1-h_ss));
m2 = (1 + m1)/(m1 + alpha);
m3 = alpha*(1 + m1)/(m1 + alpha) + (i_ss/(y_ss*delta))*(1 - delta);
m4 = (c_ss/y_ss) + (1 - alpha)/(m1 + alpha);
m5 = i_ss/(y_ss*delta);
n1 = 1+ beta*r_ss*(1 - alpha)/(m1 + alpha);
n2 = beta*r_ss*(1 + m1)/(m1 + alpha);
n3 = beta*r_ss - beta*r_ss*((1 + m1)/(m1 + alpha))*alpha;
% Ecuaci�n cuadr�tica en n_kk:
% a*n_kk^2 + b*n_kk + c
a = n1*m5;
b = -(n1*m3 + n3*m4 + m5);
c= m3;
% Coeficientes del capital y del consumo
%-----------------------------------------------------
% c�lculo de las 2 raices de la Ecuaci�n cuadr�tica en n_kk:
n_kk1(j) = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c)); % = 1.0897
n_kk2(j) = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));  % = 0.9326
n_ck(j) = (m3 - m5*n_kk2(j))/m4;
n_ka(j) = (phi*n2 + (m2/m4)*(1 - phi*n1))/((m5/m4)*(1 - phi*n1) + n1*n_ck(j) +n3);
n_ca(j) = (m2 - m5*n_ka(j))/m4;
% Coeficientes del producto
%-----------------------------------------------------
% Producto: y = n_yk*k + n_ya*a
n_ya(j) = ((1 + m1)/(m1 + alpha))*(1 - (1-alpha)*n_ca(j)/(1 + m1));
n_yk(j) = ((1 + m1)/(m1 + alpha))*(alpha - (1-alpha)*n_ck(j)/(1 + m1));
% Coeficientes del trabajo
%-----------------------------------------------------
%Trabajo: h = n_hk*k + n_ha*a
n_ha(j) = (n_ya(j) - n_ca(j))/(1 + m1);
n_hk(j) = (n_yk(j) - n_ck(j))/(1 + m1);
% Coeficientes del salario
%-----------------------------------------------------
%Salario: h = n_wk*k + n_wa*a
n_wa(j) = n_ya(j) - n_ha(j);
n_wk(j) = n_yk(j) - n_hk(j);
% Coeficientes de la inversi�n
%-----------------------------------------------------
%Inversi�n: i = n_ik*k + n_ia*a
n_ia(j) = (y_ss/i_ss)*(n_ya(j) - (c_ss/y_ss)*n_ca(j));
n_ik(j) = (y_ss/i_ss)*(n_yk(j) - (c_ss/y_ss)*n_ck(j));
% Coeficientes de la tasa de inter�s
%-----------------------------------------------------
%Tasa de inter�s: r = n_rk*k + n_ra*a
n_ra(j) = n_ya(j);
n_rk(j) = n_yk(j) - 1;
end;

% Gr�fico: Capital
%------------------------------
figure('Name','[4A] Simulaci�n de los coeficientes del capital (n_kk, n_ka)')
subplot(2,2,1)
plot(phis,n_kk1,'LineWidth',1.5);
title('n_{kk1}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,2)
plot(phis,n_kk2,'LineWidth',1.5);
title('n_{kk2}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,3:4)
plot(phis,n_ka,'LineWidth',1.5);
title('n_{ka}');
xlabel('Persistencia del choque (\phi)')
grid;

% Gr�fico: Consumo - Inversi�n
%------------------------------
figure('Name','[4B] Simulaci�n de los coeficientes del consumo-Inversi�n (n_ck, n_ca, n_ik, n_ia)')
subplot(2,2,1)
plot(phis,n_ck,'LineWidth',1.5);
title('n_{ck}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,2)
plot(phis,n_ca,'LineWidth',1.5);
title('n_{ca}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,3)
plot(phis,n_ik,'LineWidth',1.5);
title('n_{ik}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,4)
plot(phis,n_ia,'LineWidth',1.5);
title('n_{ia}');
xlabel('Persistencia del choque (\phi)')
grid;

% Gr�fico: Producto - Tasa de inter�s
%------------------------------
figure('Name','[4C] Simulaci�n de los coeficientes del producto-tasa de inter�s (n_yk, n_ya,n_ik, n_ia)')
subplot(2,2,1)
plot(phis,n_yk,'LineWidth',1.5);
title('n_{yk}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,2)
plot(phis,n_ya,'LineWidth',1.5);
title('n_{ya}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,3)
plot(phis,n_rk,'LineWidth',1.5);
title('n_{rk}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,4)
plot(phis,n_ra,'LineWidth',1.5);
title('n_{ra}');
xlabel('Persistencia del choque (\phi)')
grid;

% Gr�fico: Trabajo - Salario
%------------------------------
figure('Name','[4D] Simulaci�n de los coeficientes del trabajo-salario (n_hk, n_ha,n_wk, n_wa)')
subplot(2,2,1)
plot(phis,n_hk,'LineWidth',1.5);
title('n_{hk}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,2)
plot(phis,n_ha,'LineWidth',1.5);
title('n_{ha}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,3)
plot(phis,n_wk,'LineWidth',1.5);
title('n_{wk}');
xlabel('Persistencia del choque (\phi)')
grid;

subplot(2,2,4)
plot(phis,n_wa,'LineWidth',1.5);
title('n_{wa}');
xlabel('Persistencia del choque (\phi)')
grid;
