%% Modelo de Campbell (1994)
%{ 
Modelo A: trabajo variable
Autor: Hamilton Galindo
Fecha(update): mayo 2017
%}
%% Descripci�n
%{ 
Las secciones de  este m-file son:
 [1] Calibraci�n
 [2] C�lculo del estado estacionario (SS)
 [3] C�lculo de los coeficientes de la soluci�n (m�todo coeficientes indeterminados)
%}
%% [1] Calibraci�n 
% Calibraci�n para un modelo trimestral 
theta = 2; % corresponde a epsilon=2/3, tomado de Prescott (1986)
beta = 0.984;
delta = 0.025;       %(= 1 para el modelo de Long y Plosser, 1983)
gamma = 1;          % ESI del consumo (=1 hace que u(c) = log c)
gamma_n = 0.25; % elasticidad de Frisch (de la oferta de trabajo)
alpha = 0.333;      %participaci�n del capital en la renta nacional
phi = 0.95;            %persistencia del choque
sigma = 0.01;        %des est del choque

%% [2] C�lculo de estado estacionario 
a_ss = 1;
r_ss = 1/beta - (1-delta);
yk = (r_ss/alpha);                 %y/k
hk = (yk/a_ss)^(1/(1-alpha)); %h/k
w_ss= (1-alpha)*yk/hk;
ik = delta;                              %i/k
ck = yk - ik;
h_ss = 0.3719;              % valor obtenido de la funci�n trabajo_ss.m (con estos par�metros)
k_ss = h_ss*(hk)^(-1);
i_ss = ik*k_ss;
y_ss = yk*k_ss;
c_ss = y_ss - i_ss;

%% [3] M�todo de coeficientes indeterminados
m1 = gamma_n*(h_ss/(1-h_ss));
m2 = (1 + m1)/(m1 + alpha);
m3 = alpha*(1 + m1)/(m1 + alpha) + (i_ss/(y_ss*delta))*(1 - delta);
m4 = (c_ss/y_ss) + (1 - alpha)/(m1 + alpha);
m5 = i_ss/(y_ss*delta);

n1 = 1+ beta*r_ss*(1 - alpha)/(m1 + alpha);
n2 = beta*r_ss*(1 + m1)/(m1 + alpha);
n3 = beta*r_ss - beta*r_ss*((1 + m1)/(m1 + alpha))*alpha;
% Ecuaci�n cuadr�tica en n_kk:
% a*n_kk^2 + b*n_kk + c
a = n1*m5;
b = -(n1*m3 + n3*m4 + m5);
c= m3;

% c�lculo de las 2 raices de la Ecuaci�n cuadr�tica en n_kk:
n_kk1 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c)); % = 1.0897
n_kk2 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));  % = 0.9326
% el valor de n_kk2 es el mismo que se obtiene en Dynare:
% ver Campbell_Lvariable_Dynare_nolineal_log5.mod y
% sus resultados est�n en: Modelo_Campbell1994.xlsx

%% C�lculo de las funciones de pol�tica y estado
% Capital y el consumo
n_ck = (m3 - m5*n_kk2)/m4;
n_ka = (phi*n2 + (m2/m4)*(1 - phi*n1))/((m5/m4)*(1 - phi*n1) + n1*n_ck +n3);
n_ca = (m2 - m5*n_ka)/m4;

% Producto: y = n_yk*k + n_ya*a
n_ya = ((1 + m1)/(m1 + alpha))*(1 - (1-alpha)*n_ca/(1 + m1));
n_yk = ((1 + m1)/(m1 + alpha))*(alpha - (1-alpha)*n_ck/(1 + m1));

%Trabajo: h = n_hk*k + n_ha*a
n_ha = (n_ya - n_ca)/(1 + m1);
n_hk = (n_yk - n_ck)/(1 + m1);

%Salario: h = n_wk*k + n_wa*a
n_wa = n_ya - n_ha;
n_wk = n_yk - n_hk;

%Inversi�n: i = n_ik*k + n_ia*a
n_ia = (y_ss/i_ss)*(n_ya - (c_ss/y_ss)*n_ca);
n_ik = (y_ss/i_ss)*(n_yk - (c_ss/y_ss)*n_ck);

%Tasa de inter�s: r = n_rk*k + n_ra*a
n_ra = n_ya;
n_rk = n_yk - 1;
