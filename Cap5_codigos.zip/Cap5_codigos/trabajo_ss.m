function F=trabajo_ss(h_ss,delta, alpha, gamma_n)
%{ 
El objetivo es calcular h_ss que est� expresado en una ecuaci�n no lineal.
El modelo es de Campbell (1994) con trabajo variable.
Fecha: Mayo 2017
Autor: Hamilton Galindo
%}
%par�metros 
theta = 2; %valoraci�n del ocio en la funci�n de utilidad
gamma = 1; %inversa de la ES intertemporal del consumo = 1/gamma. (valor inicial para simulaci�n),
% este valor gamma = 1 corresponde al modelo de Campbell con trabajo
% variable 
%gamma_n = 0.25; %inversa de la elasticidad de la oferta de trabajo (frisch) = 1/gamma_n. (valor inicial para simulaci�n)
beta = 0.984; %factor de descuento
%delta = 0.025; %depreciaci�n
%alpha = 0.333; %participaci�n del capital en la renta total
phi = 0.95; %persistencia del choque
sigma_e = 0.01; %des. est. del choque
%Estado Estacionario
a_ss = 1; 
r_ss = 1/beta - (1-delta);
ik = delta; %i/k
yk = (r_ss/alpha); %y/k
hk = (yk/a_ss)^(1/(1-alpha)); %h/k
ck = yk - ik; %c/k 
w_ss= (1-alpha)*yk/hk;
%% Encontrando h_ss
% En la ecuaci�n de la oferta de trabajo: 
% Dos par�metros adicionales: gamma_1 y gamma_2
gamma_1 = theta*ck^(gamma);
gamma_2 = w_ss*hk^(gamma);
%{  
En la oferta de trabajo surge una ecuaci�n no lineal en h_ss: 
F = gamma_1*(h_ss)^(gamma) - gamma_2*(1-h_ss)^(gamma_n);
%}
F = gamma_1*(h_ss)^(gamma) - gamma_2*(1-h_ss)^(gamma_n);
% F es la ecuaci�n no lineal en hss donde todos los t�rminos se han pasado
% a la izquierda (es decir si la ecuaci�n es  y = x + 1, entonces F= y-x-1=0)
%% Obteniendo h_ss 
% En el Command Window colocar [1] y [2]
%[1] h0=0.4; valor inicial
%[2] delta = 0.025; valor de delta
%[3] h_ss= fsolve(@(h_ss) trabajo_ss(h_ss,delta,alpha,gamma_n),h0) %comando para el calculo de h_ss
% fsolve: resuelve la ecuaci�n no lineal en h_ss
% Nota:
% esta funci�n brinda estas soluciones:
%{ 
- h_ss = 0.3719 (cuando gamma=1), usado en 
 Campbell_Lvariable_Dynare_nolineal_log5.mod
- h_ss = 0.2613 (cuando gamma=0.25)
%}