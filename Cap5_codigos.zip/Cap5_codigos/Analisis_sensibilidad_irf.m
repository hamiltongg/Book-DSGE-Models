%% An�lisis de sensibilidad
%{ 
-Modelo de Campbell (1994) con trabajo variable
-Modelo de Long y Plosser
Considera el modelo no-lineal: variables en logaritmo
[1] Autor: Hamilton Galindo
[2] Fecha: Mayo 2017
Uso:
realizar an�lisis de sensibilidad: �c�mo cambia el IRF ante...
[1A]: ESI del consumo, [1B]: persistencia del choque y [1C]: Elasticidad de
Frisch, [2A] (tama�o) choque de productividad, [3A]: Tasa de depreciaci�n,
[4A]: Modelo de Campbell (1994) vs Long y Plosser (1983), 
[4B]: solo el modelo de Campbell (1994) con trabajo variable, 
%}

%% [1] An�lisis de sensibilidad del modelo de Campbell (1994):
% [1A]: ESI del consumo, [1B]: persistencia del choque y [1C]: Elasticidad de
% Frisch
% Se considera el modelo de trabajo variable
% Correr el archivo mod
dynare Campbell_Lvariable_nolineal_log1;
clear all;

%% [1A] ESI del consumo (1/gamma): tres valores
load oo_campbell_s1A;
%gammas = [5 1 0.2]
names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;

field_names = fieldnames(oo_campbell_s1A{1}.irfs);
figure('Name','[1A] ESI del consumo (1/gamma): tres valores');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_s1A{1}.irfs.(field_names{i}),'r',...
         periods, oo_campbell_s1A{2}.irfs.(field_names{i}), 'b--',...
         periods, oo_campbell_s1A{3}.irfs.(field_names{i}),'k--','LineWidth', 2);
     grid;
     title(names{i})
end;
lgd = legend({'$\gamma = 0.2$','$\gamma = 1$','$\gamma = 5$'},'Interpreter','latex');
%lgd.Box = 'off';
%lgd.Location ='south'; 
clear all;

%% [1B] (persistencia) choque de productividad: tres valores 
load oo_campbell_s1B.mat;
%phis = [0 0.3 0.6 0.99]
names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;
field_names = fieldnames(oo_campbell_s1B{1}.irfs);
figure('Name','[1B] (persistencia) choque de productividad: tres valores');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_s1B{1}.irfs.(field_names{i}),'r',...
         periods, oo_campbell_s1B{2}.irfs.(field_names{i}), 'b--',...
         periods, oo_campbell_s1B{3}.irfs.(field_names{i}), 'g-.',...
         periods, oo_campbell_s1B{4}.irfs.(field_names{i}),'k--','LineWidth', 1.5);
     grid;
     title(names{i})
 end;
legend({'$\phi = 0$','$\phi = 0.3$','$\phi = 0.6$','$\phi = 0.95$'},'Interpreter', 'latex');
clear all;

%% [1C] Elasticidad de Frisch (1/gamma_n): tres valores
load oo_campbell_s1C.mat;
%gamma_ns = [5 1 0.2]
names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;
field_names = fieldnames(oo_campbell_s1C{1}.irfs);
figure('Name','[1C] Elasticidad de Frisch (1/gamma_n): tres valores');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_s1C{1}.irfs.(field_names{i}),'r',...
         periods, oo_campbell_s1C{2}.irfs.(field_names{i}), 'b--',...
         periods, oo_campbell_s1C{3}.irfs.(field_names{i}),'k--','LineWidth', 1.5);
     grid;
     title(names{i})
 end;
legend({'$\gamma_n = 5$','$\gamma_n = 1$','$\gamma_n = 0.2$'},'Interpreter', 'latex');
clear all;

%% [2] An�lisis de sensibilidad del modelo de Campbell (1994):
% [2A]: (tama�o) choque de productividad
% Se considera el modelo de trabajo variable
% Correr el archivo mod
dynare Campbell_Lvariable_nolineal_log2;
clear all;

%% [2A] (tama�o) choque de productividad: tres valores 
load oo_campbell_s2A.mat;
%sigmas = [0.1 0.2 0.3]
names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;
field_names = fieldnames(oo_campbell_s2A{1}.irfs);
figure('Name','[2A] (tama�o) choque de productividad: tres valores ');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_s2A{1}.irfs.(field_names{i}),'r',...
         periods, oo_campbell_s2A{2}.irfs.(field_names{i}), 'b--',...
         periods, oo_campbell_s2A{3}.irfs.(field_names{i}),'k--','LineWidth', 1.5);
     grid;
     title(names{i})
 end;
legend({'$\sigma_{\epsilon} = 1$\%','$\sigma_{\epsilon} = 2$\%','$\sigma_{\epsilon} = 3$\%'},'Interpreter', 'latex');
clear all;

%% [3] An�lisis de sensibilidad del modelo de Campbell (1994):
% [3A]: Tasa de depreciaci�n
% Se considera el modelo de trabajo variable
% Correr el archivo mod
dynare Campbell_Lvariable_nolineal_log3;
clear all;

%% [3A] tasa de depreciaci�n: cuatro valores 
load oo_campbell_s3A.mat;
%deltas = [0.025 0.1 0.5 1]
names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;
field_names = fieldnames(oo_campbell_s3A{1}.irfs);
figure('Name','[3A] tasa de depreciaci�n: cuatro valores');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_s3A{1}.irfs.(field_names{i}),'r',...
         periods, oo_campbell_s3A{2}.irfs.(field_names{i}), 'b--',...
         periods, oo_campbell_s3A{3}.irfs.(field_names{i}), 'g-.',...
         periods, oo_campbell_s3A{4}.irfs.(field_names{i}),'k--','LineWidth', 1.5);
     grid;
     title(names{i})
 end;
legend({'$\delta = 0.025$','$\delta = 0.1$','$\delta = 0.5$', '$\delta = 1$'},'Interpreter', 'latex');
clear all;

%% [4] Modelo de Campbell (1994) vs Long y Plosser (1983):
% [4A]: Comparaci�n
% Se considera el modelo de trabajo variable
% Correr el archivo mod (modelo de Long y Plosser, 1983)
dynare Campbell_Lvariable_nolineal_log4;
% este mod tiene la misma calibraci�n que el modelo de Campbell (1994)
clear all;

%% Modelos
load oo_campbell_b.mat; % Campbell_Lvariable_Dynare_nolineal_log1.mod
load oo_longplosser_b.mat; % Campbell_Lvariable_Dynare_nolineal_log4.mod

names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;
field_names = fieldnames(oo_campbell_b.irfs);

% [4A]: Modelo de Campbell (1994) vs Long y Plosser (1983)
figure('Name','[4A] Modelo de Campbell (1994) vs Long y Plosser (1983)');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_b.irfs.(field_names{i}),'r',...
         periods, oo_longplosser_b.irfs.(field_names{i}),'b--','LineWidth', 1.5);
     grid;
     title(names{i})
 end;
legend('Campbell (1994)', 'Long y Plosser (1983)');

% [4B]: solo el modelo de Campbell (1994) con trabajo variable
names = {'Consumo','Inversi�n', 'Producto', 'Capital', 'Trabajo', 'Tasa de inter�s', 'Salario', 'Productividad'};
periods = 1:40;
field_names = fieldnames(oo_campbell_b.irfs);
figure('Name','[4B] Modelo de Campbell (1994) con trabajo variable');
 for i=1:8
     subplot(2,4,i)
     plot(periods, oo_campbell_b.irfs.(field_names{i}),'LineWidth', 1.5);
     grid;
     title(names{i})
 end;
