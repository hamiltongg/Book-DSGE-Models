%% Modelo de GHH(1988)
%{ 
Autor: Hamilton Galindo
Fecha: Junio 2017
Uso:
- Graficar la funci�n de depreciaci�n: delta = (1/omega)*h^(omega)
%}

h = [0:0.1:2]; % valores de la tasa de utilizaci�n variable del capital
delta = [];
omega = [0.7 1 1.42]; % tres valores de "omega"

%% C�lculo de "delta" para cada valor de "omega"
for j = 1:3;
omegas = omega(j);
delta(j,:) = (1/omegas)*(h.^(omegas));
end;

%% Gr�fica de delta: en funci�n a 3 valores de "omega"
plot(h,delta(1,:),':',h,delta(2,:),'--',h,delta(3,:), 'LineWidth', 1.5);
title('$$\delta(h_t) = \frac{h_t^{\omega}}{\omega}$$', 'interpreter', 'latex');
legend('\omega = 0.7', '\omega = 1', '\omega = 1.42', 'Orientation', 'horizontal');
xlabel('Tasa de utilizaci�n variable del capital (h_t)');
ylabel('Tasa de depreciaci�n variable (\delta(h_t))');
grid;