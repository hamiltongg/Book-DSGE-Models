%% Simulaci�n: modelo de GHH (1988)
%{
Autor : Hamilton Galindo
Fecha: Junio 2017
%}
%% Objetivo del programa
%{ 
[1] Graficar los IRF del modelo de Campbell (1994) vs GHH (1988)
Ambos modelos tienen la misma calibraci�n propuesta por GHH (1988)
%}
%% Levantar .mod
dynare Campbell_Lvariable_nolineal_log5_inv; % modelo de Campbell(1994)
dynare modelo_ghh_log1; % modelo de GHH(1988)

clear all
%% Levantar solo los archivos que contiene los dos modelos
load oo_campbell_lv_inv3.mat;   
load oo_ghh_log2.mat;

%% Gr�fica de IRF: Campbell vs GHH

irf_series_ghh = [oo_ghh_log2.irfs.yy_v;...
oo_ghh_log2.irfs.cc_v;...
oo_ghh_log2.irfs.ii_v;...
oo_ghh_log2.irfs.kk_v;...
oo_ghh_log2.irfs.ll_v;...
oo_ghh_log2.irfs.rr_v;...
oo_ghh_log2.irfs.ww_v;...
oo_ghh_log2.irfs.hh_v;...
oo_ghh_log2.irfs.ee_v];

h_aux = zeros(1,40); % este es una variable aux para 
% la variable "utilizaci�n" en el modelo de Campbell
% la cual es constante y se mantiene en el SS

irf_series_campbell = [oo_campbell_lv_inv3.irfs.yy_v;...
oo_campbell_lv_inv3.irfs.cc_v;...
oo_campbell_lv_inv3.irfs.ii_v;...
oo_campbell_lv_inv3.irfs.kk_v;...
oo_campbell_lv_inv3.irfs.hh_v;...
oo_campbell_lv_inv3.irfs.rr_v;...
oo_campbell_lv_inv3.irfs.ww_v;...
h_aux;...
oo_campbell_lv_inv3.irfs.ee_v];

%{ 
Nota: en el modelo de Campbell: "h" representa trabajo,
mientras que "h" en el modelo de GHH representa "utilizaci�n variable del capital"
y "l" es el trabajo.
%}

periodos = 1:40;
names = {'Producto', 'Consumo', 'Inversi�n', 'Capital', 'Trabajo', 'Tasa de inter�s',...
               'Salario real','Utilizaci�n variable del capital', 'Choque a la inversi�n'};
%----------------------------%
figure('Name','Modelo de Campbell (1994) vs modelo de GHH (1988))');
for j=1:8
subplot(2,4,j)
plot(periodos, irf_series_campbell(j,:),periodos, irf_series_ghh(j,:),'r--','LineWidth', 1.5)
title(names{j});
grid;
end
legend('Modelo de Campbell(1994)', 'Modelo de Greenwood et al (1988)', 'orientation', 'horizontal');